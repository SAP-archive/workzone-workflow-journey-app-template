$.context.journeyApp.state = "waitForCloseCompleteAfterLeaveRejected";
$.context.journeyApp.readyForMessage = "confirm_error";
$.context.journeyApp.progress = "Workflow will be closed"; 