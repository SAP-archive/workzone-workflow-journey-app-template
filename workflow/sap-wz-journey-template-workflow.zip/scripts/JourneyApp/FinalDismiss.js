$.context.journeyApp.state = "waitForFinalDismiss";
$.context.journeyApp.readyForMessage = "final_dismiss";
$.context.journeyApp.progress = "Waiting for final dismiss";