$.context.journeyApp.state = "waitForLeaveRequest";
$.context.journeyApp.readyForMessage = "request_leave";
$.context.journeyApp.progress = "Waiting for Leave Request Details";
