$.context.journeyApp.discussLeave.status = 'completed';

$.context.journeyApp.state = "waitForFeedback";
$.context.journeyApp.readyForMessage = "wait_for_feedback";
$.context.journeyApp.progress = "Waiting for feedback upload";
