$.context.journeyApp.state = "waitForConfirmComplete";
$.context.journeyApp.readyForMessage = "confirm_complete";
$.context.journeyApp.progress = "Waiting for confirm complete";
