$.context.journeyApp.state = "receivedFeedback";
$.context.journeyApp.readyForMessage = null;
$.context.journeyApp.progress = "Received Feedback";

$.context.journeyApp.feedback.status = 'completed';