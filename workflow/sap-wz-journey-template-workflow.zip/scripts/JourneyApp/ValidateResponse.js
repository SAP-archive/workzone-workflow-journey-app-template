$.context.journeyApp.progress = "Service Now Request Completed";

// check snow response object

$.context.journeyApp.consultation.status = "completed";
