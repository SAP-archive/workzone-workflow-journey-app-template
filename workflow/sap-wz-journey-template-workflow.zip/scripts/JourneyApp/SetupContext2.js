$.context.journeyApp.progress = "Creating Service Now Incident";

$.context.snowRequest = {
    "caller_id": "Aanya Singh",
    "short_description": "Parental Leave Request",
    "category": $.context.journeyApp.consultation.category
};
