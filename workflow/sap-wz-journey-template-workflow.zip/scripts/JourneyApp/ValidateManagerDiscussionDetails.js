$.context.journeyApp.readyForMessage = null;
$.context.journeyApp.state = "receivedManagerDiscussionMeetingRequest";
$.context.journeyApp.progress = "Waiting for Manager to confirm Meeting request";
