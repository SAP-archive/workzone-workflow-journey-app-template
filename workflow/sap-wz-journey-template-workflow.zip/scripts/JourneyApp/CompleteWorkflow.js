$.context.journeyApp.state = "receivedConfirmComplete";
$.context.journeyApp.readyForMessage = null;
$.context.journeyApp.progress = "Complete Confirm Received";