$.context.journeyApp.state = "complete";
$.context.journeyApp.readyForMessage = null;
$.context.journeyApp.progress = "Workflow is closed";