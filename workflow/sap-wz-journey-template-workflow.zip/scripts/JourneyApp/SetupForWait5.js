$.context.journeyApp.state = "waitForConsultation";
$.context.journeyApp.readyForMessage= "consultation_message";
$.context.journeyApp.progress = "Waiting for new due date";
