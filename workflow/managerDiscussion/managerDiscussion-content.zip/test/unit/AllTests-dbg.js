sap.ui.define([
	"com/sap/wz/journey/managerDiscussion/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
